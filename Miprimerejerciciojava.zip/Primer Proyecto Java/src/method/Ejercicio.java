package method;


public class Ejercicio {
	
	public static final Double PI = 3.14;
	

	public static void main(String[] args) {
				
		// Variables
		
		// Inicio
		
				
				
	}
	
	public static int numeroSolucionesEcuacionSegundoGrado(int a, int b, int c) {
		int result ;
		resul = b*b -4*a*c;
		int result;
		if (a==0) {
			return -1;
		}else if (result == 0) {
			return 1;
		}else if (result<0) {
			return 0;
		}else {
			return 2;
		}
	}
	public static Double solucionSumaEcuacionSegundoGrado(int a, int b, int c) {
		int result;
		result=numeroSolucionesEcuacionSegundoGrado(a,b,c);
		Double ecuacion;
		ecuacion=(-b + Math.sqrt(b*b-4*a*c))/(2*a);
		if (result<=0) {
			return (double)-1000;
		}else if (result>0) {
			return ecuacion;
		}else {
			return (double) -1000
		}
	}
	
	
	
	public static Double solucionRestaEcuacionSegundoGrado(int a, int b, int c) {
		int result;
		result=numeroSolucionesEcuacionSegundoGrado(a,b,c);
		Double ecuacion;
		ecuacion=(-b - Math.sqrt(b*b-4*a*c))/(2*a);
		if (result<=0) {
			return (double)-1000;
		}else if (result>0) {
			return ecuacion;
		}else {
			return (double) -1000
		}
	}	
	
	public static Double areaCirculo(Double r) {
		Double areaCirculo;
		areaCirculo=(PI*r*r);{
			return(areaCirculo);
		}
	}
	
	public static Double longitudCirculo(Double r) {
		Double radio = 2*PI*r;
		return radio;
	}
	
	public static boolean esMultiplo(int a, int b) {
		if (a==0	||	b==0) {
			return false;
			
		}
		else if (a%b==0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static int horaMayor(int hora1, int min1, int seg1, int hora2, int min2, int seg2) {
		int hora1M;
		hora1M=hora1*3600+min1*60+seg1;
		int hora2M;
		hora2M=hora2*3600+min2*60+seg2;
		if((hora1>=24 || min1>59 || seg1>59) || (hora2>=24|| min2>59||seg2>59)){
			return -1000;
		}
		else if (hora1M>hora2M) {
			return 1;
		}
		else if (hora2M>hora1M) {
			return 2;
		}
		else {
			return 0;
		}
	}
	
	public static int segundosEntre(int hora1, int min1, int seg1, int hora2, int min2, int seg2) {
		int diferencia;
		diferencia=horaMayor;
		if ()
		
	}
	
	public static int maximoComunDivisor(int a, int b) {
		
	}
	
	public static int minimoComunMultiplo(int a, int b) {
		
	}
	
	public static String binario(int num) {
		
	}
	
	public static int decimal(String num) {
		
	}
}
